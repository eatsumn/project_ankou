<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Screenshot 2026-04-21 205251" tilewidth="16" tileheight="16" tilecount="575" columns="25">
 <image source="Screenshot 2026-04-21 205251.png" width="406" height="383"/>
</tileset>
