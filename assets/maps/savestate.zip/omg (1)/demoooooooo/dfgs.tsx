<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Screenshot 2026-04-21 210952" tilewidth="16" tileheight="16" tilecount="4" columns="2">
 <image source="Screenshot 2026-04-21 210952.png" width="32" height="37"/>
</tileset>
