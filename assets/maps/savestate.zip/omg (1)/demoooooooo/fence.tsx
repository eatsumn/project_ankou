<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="fence" tilewidth="16" tileheight="16" tilecount="152" columns="19">
 <image source="Screenshot 2026-04-21 205822.png" width="311" height="137"/>
</tileset>
