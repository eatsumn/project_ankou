<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Screenshot 2026-04-21 210212" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="Screenshot 2026-04-21 210212.png" width="21" height="24"/>
</tileset>
