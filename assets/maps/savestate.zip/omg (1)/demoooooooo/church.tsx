<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="church" tilewidth="16" tileheight="16" tilecount="594" columns="33">
 <image source="Screenshot 2026-04-21 220539.png" width="533" height="290"/>
</tileset>
